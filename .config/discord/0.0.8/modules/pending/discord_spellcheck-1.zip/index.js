module.exports = {
  cld: require('cld'),
  Spellchecker: require('spellchecker').Spellchecker,
  keyboardLayout: require('keyboard-layout'),
};
